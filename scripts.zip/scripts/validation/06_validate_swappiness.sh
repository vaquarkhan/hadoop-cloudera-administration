./main.sh ${1} "sysctl -a|grep swappiness"
