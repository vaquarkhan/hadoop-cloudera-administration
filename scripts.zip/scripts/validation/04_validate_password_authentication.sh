./main.sh ${1} "grep ^PasswordAuthentication\ yes /etc/ssh/sshd_config"
